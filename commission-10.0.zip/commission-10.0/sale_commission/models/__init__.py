# -*- coding: utf-8 -*-

from . import product_template
from . import sale_commission
from . import sale_commission_mixin
from . import res_partner
from . import sale_order
from . import account_invoice
from . import settlement
