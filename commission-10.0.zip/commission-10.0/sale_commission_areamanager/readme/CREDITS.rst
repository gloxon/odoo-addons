* http://commons.wikimedia.org/wiki/File:Percent_18e.svg
* https://openclipart.org/detail/43969/pile-of-golden-coins-by-j_alves
