This module extends the functionality of Sale Commission and allow
you to compute settlement to the Area Manager agent.
Area Manager is computed when saving Sale Order or Account Invoice
