For an agent, you can configure an area manager, with their own commission. For every area manager, different commissions can be applied, depending on the sub agent who is doing sale order.
