# -*- coding: utf-8 -*-

from . import areamanager_test
