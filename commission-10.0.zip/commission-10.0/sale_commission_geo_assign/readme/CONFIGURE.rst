Go to

Sales > Commissions Management > Agents

For every agent, you can set Countries, States or ZIP range
