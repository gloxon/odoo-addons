Configure sales agents assigning them to a specific geographical area.

Then, automatically assign agents to customers, according to their geographical area.
