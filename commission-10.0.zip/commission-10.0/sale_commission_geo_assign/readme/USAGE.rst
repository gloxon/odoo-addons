Go to

Sales > Customers

Select the customers you want to assign agents to and click

Action > Geo assign agents
