# -*- coding: utf-8 -*-

from . import test_sale_commission_pricelist
