This module allows to assign agents to field *Assigned Partner* of leads, according to their location:

* The agent's location is specified in the tab *Agent information*;
* The lead's location is computed by its address.

Agents are assigned to leads right after lead creation.

This module comes with a CRON (to be activated) that assigns agents to all the leads.
