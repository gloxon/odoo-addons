Select *Geo assign agents* from the lead's context menu.

The CRON can get two parameters:

* check_existing_agents: used in the same way of the homonym field in the wizard
* leads: a recordset of leads to assign (all leads if nothing is specified)
